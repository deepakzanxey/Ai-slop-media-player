# Glasswave Player — Android build project

This wraps the Glasswave glassmorphism media-player UI in a simple Android WebView app. It includes an Android file picker for local media and a GitHub Actions workflow that builds a debug APK.

## Get the APK

This environment does not have the Android SDK/Gradle installed, so it cannot compile the APK locally. To build it in GitHub:

1. Create a new GitHub repository and upload the contents of this folder (not the parent folder).
2. Open **Actions** and run **Build Glasswave APK** (or push to `main`).
3. Open the completed workflow run and download the **Glasswave-Player-APK** artifact.
4. Extract it; `app-debug.apk` is the installable APK. Android may ask you to allow installs from your browser/files app.

## Features / limitations
- Glassmorphism responsive UI, local audio/video selection, playlist, seek, speed control, external SRT/VTT subtitle loading, fullscreen.
- Actual codec support depends on Android's WebView/media stack. This is not yet a full VLC/Media3 implementation; some MKV/AVI codecs and embedded subtitle/audio-track selection may not work.
- Debug APK is unsigned for Play Store release but can be installed manually.
