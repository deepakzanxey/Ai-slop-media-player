const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('glasswave', {
  pickMedia: () => ipcRenderer.invoke('pick-media'),
  pickSubtitle: () => ipcRenderer.invoke('pick-subtitle'),
  openExternal: (url) => ipcRenderer.invoke('open-external', url),
  isDesktop: true
});
