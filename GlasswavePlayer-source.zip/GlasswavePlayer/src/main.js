const { app, BrowserWindow, dialog, ipcMain, shell } = require('electron');
const path = require('path');

function createWindow() {
  const win = new BrowserWindow({
    width: 1440, height: 920, minWidth: 900, minHeight: 620,
    backgroundColor: '#10131c', title: 'Glasswave Player',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false }
  });
  win.loadFile(path.join(__dirname, '../public/index.html'));
}
app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

ipcMain.handle('pick-media', async () => {
  const result = await dialog.showOpenDialog({
    properties: ['openFile', 'multiSelections'],
    filters: [{ name: 'Media', extensions: ['mp3','mp4','m4v','mkv','webm','mov','avi','wav','flac','aac','ogg','opus','m4a','3gp','ts','mpeg','mpg'] }, { name: 'All files', extensions: ['*'] }]
  });
  return result.canceled ? [] : result.filePaths.map(p => ({ path: p, name: path.basename(p), url: require('url').pathToFileURL(p).href }));
});
ipcMain.handle('pick-subtitle', async () => {
  const result = await dialog.showOpenDialog({ properties: ['openFile'], filters: [{ name: 'Subtitle files', extensions: ['srt','vtt','ass','ssa','sub'] }] });
  if (result.canceled || !result.filePaths.length) return null;
  const fs = require('fs');
  return { name: path.basename(result.filePaths[0]), content: fs.readFileSync(result.filePaths[0], 'utf8') };
});
ipcMain.handle('open-external', async (_, url) => { if (/^https:\/\//.test(url)) await shell.openExternal(url); });
