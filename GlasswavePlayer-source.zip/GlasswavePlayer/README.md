# Glasswave Player

A glassmorphism-inspired local media player UI with a responsive web/PWA version and an Electron desktop wrapper.

## Included
- Glass / Pinterest-inspired dark visual design
- Open multiple local media files; drag-and-drop; playlist and filtering
- MP3 and common browser-supported audio/video playback (MP4/H.264 support depends on the platform's bundled codecs)
- Play/pause, seek, skip ±10s, previous/next, fullscreen, mute, playback speed (0.5×–2×)
- External SRT/VTT subtitle loading (ASS/SSA need conversion)
- Responsive layout for phone screens; PWA manifest/service worker
- Electron native file picker for Windows desktop

## Run the Windows app from a Windows PC
1. Install Node.js LTS from https://nodejs.org/.
2. Extract this folder and open a terminal inside it.
3. Run `npm install`
4. Run `npm start` to test.
5. Run `npm run dist` to create `release/Glasswave-Player.exe`.

The `dist` command creates a portable Windows executable. Building Windows artifacts is best done on Windows; this project has not been compiled or verified as an `.exe` in this environment.

## Android
The included responsive web app is a PWA-style starting point. Serve `public/` over HTTPS and open it in Chrome, then use **Install app / Add to Home screen**. Browser/PWA file access and codec support are more limited than a native player. A native Android release with broad format support would need an Android Media3/ExoPlayer integration and a separate signed APK build.

## Limitations
This is a functional starter, not a VLC replacement yet. Browser/Electron playback cannot guarantee every codec/container (notably every MKV/AVI variant, DTS/AC3 audio, or HEVC) on every device. Subtitle support here is SRT/VTT; embedded subtitle/audio-track selection and advanced filters/equalizer/network streams are not implemented. No bundled codecs are included.
